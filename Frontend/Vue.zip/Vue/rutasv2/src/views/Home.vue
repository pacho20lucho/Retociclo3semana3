<template>
  <div class="home">    
    <the-home />
  </div>
</template>

<script>
// @ is an alias to /src
import TheHome from '@/components/TheHome.vue'

export default {
  name: 'Home',
  components: {
    TheHome
  }
}
</script>
