<template>
    <div id="servicios">
        <h2>Servicios</h2>
        <p>Hola desde la pagina de servicios</p>



    </div>
    
</template>